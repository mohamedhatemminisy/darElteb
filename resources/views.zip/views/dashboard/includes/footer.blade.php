<footer class="footer footer-static">
    <p>
        &copy; {{date('Y')}} {{trans('admin.copyright')}}
        <a class="text-bold-800" href="http://orcav.com" target="_blank">{{trans('admin.orcavision')}}</a>,{{trans('admin.rightreserved')}}. 

    </p>
</footer>
